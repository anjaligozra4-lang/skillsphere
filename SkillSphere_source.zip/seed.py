from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.security import hash_password
from app.models import User


def ensure_admin(db: Session) -> None:
    settings = get_settings()
    if not settings.admin_password:
        return

    email = settings.admin_email.strip().lower()
    if not email or db.scalar(select(User).where(User.email == email)):
        return

    db.add(User(
        email=email,
        password_hash=hash_password(settings.admin_password),
        full_name=settings.admin_full_name.strip() or "SkillSphere Administrator",
        role="admin",
        is_active=True,
    ))
    db.commit()
